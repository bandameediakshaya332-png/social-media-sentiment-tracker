import matplotlib.pyplot as plt

def show_chart(posts):

    positive = 0
    negative = 0
    neutral = 0

    for row in posts:

        if row[3] == "Positive":
            positive += 1

        elif row[3] == "Negative":
            negative += 1

        else:
            neutral += 1

    labels = ["Positive", "Negative", "Neutral"]

    values = [positive, negative, neutral]

    plt.bar(labels, values)

    plt.title("Sentiment Analysis")

    plt.xlabel("Sentiment")

    plt.ylabel("Posts")

    plt.show()