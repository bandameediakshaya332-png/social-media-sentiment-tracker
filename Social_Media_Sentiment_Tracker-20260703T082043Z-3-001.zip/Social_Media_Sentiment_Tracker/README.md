# Social Media Sentiment Tracker

## Mini Project

### Project Description

The **Social Media Sentiment Tracker** is a Python-based application developed to analyze the sentiment of social media posts. The project uses **Natural Language Processing (NLP)** techniques to classify text as **Positive**, **Negative**, or **Neutral**.

The application imports social media posts from a CSV file, performs sentiment analysis using the **TextBlob** library, stores the results in an **SQLite** database, and generates analytics and visual reports.

This project demonstrates the practical use of Python, NLP, databases, and data visualization for social media analysis.

---

## Objectives

- Analyze customer opinions from social media posts.
- Perform sentiment classification using NLP.
- Store sentiment data in a database.
- Generate statistical reports.
- Visualize sentiment distribution using charts.

---

## Technologies Used

- Python 3.x
- SQLite
- Pandas
- TextBlob
- Matplotlib

---

## Project Modules

### 1. Database Module

- Create Database
- Insert Posts
- Retrieve Data
- Delete Data
- Update Data

### 2. Sentiment Analysis Module

- Analyze Text
- Classify Sentiment
- Calculate Polarity
- Determine Positive, Negative, and Neutral Sentiments

### 3. Data Import Module

- Import CSV File
- Read Social Media Posts
- Store Data into Database

### 4. Analytics Module

- Total Posts
- Positive Posts
- Negative Posts
- Neutral Posts
- Sentiment Percentage

### 5. Dashboard Module

- Display Sentiment Summary
- Show Analysis Results

### 6. Visualization Module

- Pie Chart
- Bar Chart
- Sentiment Distribution Graph

---

## Features

- Import CSV Data
- Automatic Sentiment Analysis
- SQLite Database Storage
- Analytics Dashboard
- Data Visualization
- Easy-to-use Interface

---

## Folder Structure

```
Social_Media_Sentiment_Tracker/
│
├── main.py
├── database.py
├── sentiment.py
├── analytics.py
├── dashboard.py
├── data_import.py
├── requirements.txt
├── README.md
│
├── database/
│   └── sentiment.db
│
├── data/
│   └── sample_posts.csv
│
├── reports/
│
└── assets/
```

---

## Installation

Install the required libraries:

```bash
pip install -r requirements.txt
```

---

## Required Libraries

```
pandas
textblob
matplotlib
openpyxl
```

---

## Run the Project

```bash
python main.py
```

---

## Sample Dataset

The input dataset is stored in:

```
data/sample_posts.csv
```

Example:

| Post |
|------|
| I love this phone |
| Worst product ever |
| Amazing experience |
| Very disappointed |
| Excellent service |

---

## Future Enhancements

- Twitter API Integration
- Instagram Comment Analysis
- Facebook Sentiment Analysis
- Live Sentiment Dashboard
- AI-Based Emotion Detection
- PDF and Excel Report Generation
- User Login System

---

## Advantages

- Fast sentiment analysis
- Easy data management
- User-friendly application
- Graphical visualization
- Accurate text classification
- Useful for business decision-making

---

## Applications

- Social Media Monitoring
- Brand Reputation Analysis
- Customer Feedback Analysis
- Product Review Analysis
- Marketing Research
- Public Opinion Analysis

---

## Conclusion

The **Social Media Sentiment Tracker** provides an effective solution for analyzing social media posts using Natural Language Processing. The project combines sentiment analysis, database management, analytics, and visualization into a single application, making it suitable as a Computer Science mini project and a foundation for future AI-based sentiment analysis systems.

---

# Developer

Candidate Name: B.Akshaya

Intern ID: CITS2690

B.Tech – Computer Science and Engineering

Data Science Internship Mini Project