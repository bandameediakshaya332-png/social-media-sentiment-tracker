import sqlite3

DB_NAME = "sentiment.db"

def connect():
    return sqlite3.connect(DB_NAME)

def create_table():
    conn = connect()
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS posts(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        post TEXT,
        polarity REAL,
        sentiment TEXT
    )
    """)

    conn.commit()
    conn.close()

def insert_post(post, polarity, sentiment):
    conn = connect()
    cursor = conn.cursor()

    cursor.execute(
        "INSERT INTO posts(post,polarity,sentiment) VALUES(?,?,?)",
        (post, polarity, sentiment)
    )

    conn.commit()
    conn.close()

def get_all_posts():
    conn = connect()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM posts")
    rows = cursor.fetchall()

    conn.close()
    return rows