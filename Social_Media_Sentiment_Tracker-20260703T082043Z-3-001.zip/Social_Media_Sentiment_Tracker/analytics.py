from collections import Counter

def statistics(posts):

    positive = 0
    negative = 0
    neutral = 0

    for row in posts:

        if row[3] == "Positive":
            positive += 1

        elif row[3] == "Negative":
            negative += 1

        else:
            neutral += 1

    total = len(posts)

    print("\n------ Statistics ------")

    print("Total :", total)
    print("Positive :", positive)
    print("Negative :", negative)
    print("Neutral :", neutral)