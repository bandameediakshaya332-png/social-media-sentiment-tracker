from database import *
from sentiment import *
from data_import import *
from analytics import *
from dashboard import *

create_table()

posts = load_csv("data/sample_posts.csv")

for post in posts:

    polarity, sentiment = analyze_sentiment(post)

    insert_post(post, polarity, sentiment)

records = get_all_posts()

print("\nStored Posts\n")

for row in records:
    print(row)

statistics(records)

show_chart(records)